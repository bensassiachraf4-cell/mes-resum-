// Intégration Google Classroom + Google Drive (Google Cloud OAuth, côté navigateur)
import { extractText } from './importer.js';

const SCOPES = [
  'https://www.googleapis.com/auth/classroom.courses.readonly',
  'https://www.googleapis.com/auth/classroom.coursework.me.readonly',
  'https://www.googleapis.com/auth/classroom.courseworkmaterials.readonly',
  'https://www.googleapis.com/auth/classroom.announcements.readonly',
  'https://www.googleapis.com/auth/drive.readonly',
].join(' ');

const CFG_KEY = 'google_client_id';
let gisPromise = null;
export const gc = { token: null, expires: 0, clientId: '' };

export async function loadClientId() {
  try {
    if (window.puter?.auth?.isSignedIn()) {
      const v = await puter.kv.get(CFG_KEY);
      if (v) { gc.clientId = v; return v; }
    }
  } catch (e) {}
  gc.clientId = localStorage.getItem(CFG_KEY) || '';
  return gc.clientId;
}

export async function saveClientId(id) {
  gc.clientId = id.trim();
  localStorage.setItem(CFG_KEY, gc.clientId);
  try { if (window.puter?.auth?.isSignedIn()) await puter.kv.set(CFG_KEY, gc.clientId); } catch (e) {}
}

function loadGis() {
  if (window.google?.accounts?.oauth2) return Promise.resolve();
  if (gisPromise) return gisPromise;
  gisPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => { gisPromise = null; reject(new Error('Impossible de charger Google Identity Services.')); };
    document.head.appendChild(s);
  });
  return gisPromise;
}

export function isConnected() { return !!gc.token && Date.now() < gc.expires; }

export async function connect() {
  if (!gc.clientId) throw new Error("Ajoutez d'abord votre ID client Google Cloud.");
  await loadGis();
  return new Promise((resolve, reject) => {
    const client = google.accounts.oauth2.initTokenClient({
      client_id: gc.clientId,
      scope: SCOPES,
      callback: (resp) => {
        if (resp.error) return reject(new Error(resp.error_description || resp.error));
        gc.token = resp.access_token;
        gc.expires = Date.now() + (Number(resp.expires_in || 3600) - 60) * 1000;
        resolve();
      },
      error_callback: (err) => reject(new Error(err?.message || 'Connexion Google annulée.')),
    });
    client.requestAccessToken({ prompt: '' });
  });
}

export function disconnect() {
  if (gc.token && window.google?.accounts?.oauth2) google.accounts.oauth2.revoke(gc.token, () => {});
  gc.token = null; gc.expires = 0;
}

async function api(url, as = 'json') {
  if (!isConnected()) throw new Error('Session Google expirée. Reconnectez-vous.');
  const r = await fetch(url, { headers: { Authorization: `Bearer ${gc.token}` } });
  if (!r.ok) {
    let msg = `Erreur Google (${r.status})`;
    try { const j = await r.json(); msg = j.error?.message || msg; } catch (e) {}
    if (r.status === 401) gc.token = null;
    throw new Error(msg);
  }
  return as === 'json' ? r.json() : as === 'text' ? r.text() : r.blob();
}

export async function listCourses() {
  const j = await api('https://classroom.googleapis.com/v1/courses?courseStates=ACTIVE&pageSize=50');
  return j.courses || [];
}

function normMaterials(list = []) {
  return list.map((m) => {
    if (m.driveFile) {
      const f = m.driveFile.driveFile || {};
      return { kind: 'drive', id: f.id, title: f.title || 'Fichier Drive', url: f.alternateLink, thumb: f.thumbnailUrl };
    }
    if (m.youtubeVideo) {
      const y = m.youtubeVideo;
      return { kind: 'youtube', id: y.id, title: y.title || 'Vidéo YouTube', url: y.alternateLink || `https://www.youtube.com/watch?v=${y.id}`, thumb: y.thumbnailUrl };
    }
    if (m.link) return { kind: 'link', title: m.link.title || m.link.url, url: m.link.url, thumb: m.link.thumbnailUrl };
    if (m.form) return { kind: 'form', title: m.form.title || 'Formulaire', url: m.form.formUrl };
    return null;
  }).filter(Boolean);
}

export async function listItems(courseId) {
  const base = `https://classroom.googleapis.com/v1/courses/${courseId}`;
  const [work, mats, ann] = await Promise.allSettled([
    api(`${base}/courseWork?pageSize=50`),
    api(`${base}/courseWorkMaterials?pageSize=50`),
    api(`${base}/announcements?pageSize=30`),
  ]);
  const items = [];
  if (work.status === 'fulfilled') (work.value.courseWork || []).forEach((w) => items.push({
    id: w.id, type: 'Devoir', title: w.title, description: w.description || '', updated: w.updateTime, link: w.alternateLink, materials: normMaterials(w.materials),
  }));
  if (mats.status === 'fulfilled') (mats.value.courseWorkMaterial || []).forEach((w) => items.push({
    id: w.id, type: 'Support de cours', title: w.title, description: w.description || '', updated: w.updateTime, link: w.alternateLink, materials: normMaterials(w.materials),
  }));
  if (ann.status === 'fulfilled') (ann.value.announcements || []).filter((a) => a.materials?.length).forEach((a) => items.push({
    id: a.id, type: 'Annonce', title: (a.text || 'Annonce').split('\n')[0].slice(0, 90), description: a.text || '', updated: a.updateTime, link: a.alternateLink, materials: normMaterials(a.materials),
  }));
  if (!items.length && work.status === 'rejected' && mats.status === 'rejected') throw work.reason;
  return items.sort((a, b) => (b.updated || '').localeCompare(a.updated || ''));
}

// Récupère le texte d'un fichier Drive (Docs, Slides, PDF, Word, texte)
export async function driveText(fileId) {
  const meta = await api(`https://www.googleapis.com/drive/v3/files/${fileId}?fields=id,name,mimeType&supportsAllDrives=true`);
  const mt = meta.mimeType || '';
  let text = '';
  if (mt === 'application/vnd.google-apps.document' || mt === 'application/vnd.google-apps.presentation') {
    text = await api(`https://www.googleapis.com/drive/v3/files/${fileId}/export?mimeType=text/plain`, 'text');
  } else if (mt === 'application/vnd.google-apps.spreadsheet') {
    text = await api(`https://www.googleapis.com/drive/v3/files/${fileId}/export?mimeType=text/csv`, 'text');
  } else if (mt.startsWith('application/vnd.google-apps')) {
    throw new Error("Ce type de fichier Google n'est pas pris en charge.");
  } else {
    const blob = await api(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&supportsAllDrives=true`, 'blob');
    const file = new File([blob], meta.name, { type: mt || blob.type });
    text = await extractText(file);
  }
  return { name: meta.name, text };
}
