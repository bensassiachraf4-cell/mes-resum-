// Compte Puter, progression et cours importés (stockés dans le cloud de l'utilisateur)
export const state = {
  user: null,
  ready: false,
  progress: new Set(),
  imported: [],
  voiceMode: 'browser',
};
const listeners = new Set();
export const onChange = (fn) => listeners.add(fn);
const emit = () => listeners.forEach((f) => f());

const signedIn = () => { try { return !!window.puter?.auth?.isSignedIn(); } catch (e) { return false; } };
export const isSignedIn = signedIn;

async function kvGet(key) {
  const v = await puter.kv.get(key);
  if (v == null) return null;
  if (typeof v === 'string') { try { return JSON.parse(v); } catch (e) { return v; } }
  return v;
}
const kvSet = (key, val) => puter.kv.set(key, JSON.stringify(val));

async function loadUserData() {
  try {
    const p = await kvGet('progress');
    state.progress = new Set(Array.isArray(p) ? p : []);
  } catch (e) {}
  try {
    const list = await puter.kv.list('course:', true);
    state.imported = (list || []).map((x) => {
      const v = x.value;
      if (typeof v === 'string') { try { return JSON.parse(v); } catch (e) { return null; } }
      return v;
    }).filter(Boolean).sort((a, b) => (b.created || 0) - (a.created || 0));
  } catch (e) {}
  try { const vm = await kvGet('voiceMode'); if (vm) state.voiceMode = vm; } catch (e) {}
}

export async function initAuth() {
  if (signedIn()) {
    try { state.user = await puter.auth.getUser(); await loadUserData(); } catch (e) {}
  }
  state.ready = true;
  emit();
}

export async function signIn() {
  await puter.auth.signIn();
  state.user = await puter.auth.getUser();
  await loadUserData();
  emit();
}

export function signOut() {
  puter.auth.signOut();
  state.user = null;
  state.progress = new Set();
  state.imported = [];
  state.voiceMode = 'browser';
  emit();
}

export async function toggleDone(key) {
  if (state.progress.has(key)) state.progress.delete(key); else state.progress.add(key);
  if (signedIn()) { try { await kvSet('progress', [...state.progress]); } catch (e) {} }
}

export async function setVoiceMode(m) {
  state.voiceMode = m;
  if (signedIn()) { try { await kvSet('voiceMode', m); } catch (e) {} }
}

export async function saveImported(course) {
  await kvSet('course:' + course.id, course);
  state.imported = [course, ...state.imported.filter((c) => c.id !== course.id)];
}

export async function deleteImported(id) {
  await puter.kv.del('course:' + id);
  state.imported = state.imported.filter((c) => c.id !== id);
}

export async function saveOriginalFile(file) {
  try {
    await puter.fs.write(`ISET-Revisions/imports/${file.name}`, file, { createMissingParents: true, dedupeName: true });
  } catch (e) {}
}
