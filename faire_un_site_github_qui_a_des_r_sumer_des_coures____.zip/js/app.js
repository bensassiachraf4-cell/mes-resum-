import { createIcons, icons } from 'https://cdn.jsdelivr.net/npm/lucide@latest/+esm';
import { SUBJECTS, TPS, getSubject, getChapter, getTP } from './data.js';
import { state, initAuth, signIn, signOut, onChange, toggleDone, setVoiceMode, saveImported, deleteImported, saveOriginalFile, isSignedIn } from './store.js';
import { podcastScript, videoSlides, Narrator } from './media.js';
import { extractText, summarize } from './importer.js';
import * as GC from './classroom.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = (n, cls = 'w-4 h-4') => `<i data-lucide="${n}" class="${cls}"></i>`;
const paintIcons = () => createIcons({ icons, attrs: { 'stroke-width': 2 } });
const OTHER = { id: 'autre', name: 'Autre matière', icon: 'book-open', color: '#475569', soft: '#f1f5f9' };
const subj = (id) => getSubject(id) || OTHER;

// ---------- Modèle unifié ----------
function getItem(key) {
  const [t, a, b] = key.split('~');
  if (t === 'c') { const c = getChapter(a, b); return c && { ...c, key, kind: 'cours', subjectId: a, href: `#/cours/${a}/${b}` }; }
  if (t === 't') { const tp = getTP(a); return tp && { ...tp, key, kind: 'tp', subjectId: tp.subject, href: `#/tp/${a}` }; }
  if (t === 'i') { const c = state.imported.find((x) => x.id === a); return c && { ...c, key, kind: c.kind || 'cours', subjectId: c.subjectId, href: `#/mes-cours/${a}`, imported: true }; }
  return null;
}
function allItems() {
  const out = [];
  SUBJECTS.forEach((s) => s.chapters.forEach((c) => out.push(getItem(`c~${s.id}~${c.id}`))));
  TPS.forEach((t) => out.push(getItem(`t~${t.id}`)));
  state.imported.forEach((c) => out.push(getItem(`i~${c.id}`)));
  return out.filter(Boolean);
}
const minutesOf = (segs) => Math.max(1, Math.round(segs.reduce((n, s) => n + (s.text || '').split(/\s+/).length, 0) / 150));

// ---------- Toast ----------
function toast(msg, type = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${type === 'err' ? 'toast-err' : ''}`;
  el.innerHTML = `${icon(type === 'err' ? 'circle-alert' : 'circle-check', 'w-4 h-4 shrink-0')}<span>${esc(msg)}</span>`;
  $('#toasts').appendChild(el);
  paintIcons();
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 3600);
}

// ================= PODCAST PLAYER (global) =================
const player = { key: null, segs: [], idx: 0, playing: false, narrator: null, rate: 1 };

function startPodcast(key, from = 0) {
  const item = getItem(key);
  if (!item) return;
  closeVideo();
  if (player.narrator) player.narrator.stop();
  player.key = key;
  player.segs = podcastScript(item, subj(item.subjectId).name, item.kind);
  player.idx = from;
  player.narrator = new Narrator(player.segs, {
    onSegment: (i) => { player.idx = i; syncPlayer(); },
    onState: (p) => { player.playing = p; syncPlayer(); },
    onEnd: () => { player.idx = player.segs.length - 1; syncPlayer(); },
    onError: (e) => toast(e.message || 'Erreur de lecture', 'err'),
  });
  player.narrator.rate = player.rate;
  player.narrator.play(from);
  renderPlayerBar();
}
function stopPodcast() {
  player.narrator?.stop();
  player.key = null; player.narrator = null; player.playing = false;
  renderPlayerBar(); syncPlayer();
}
function renderPlayerBar() {
  const bar = $('#player');
  if (!player.key) { bar.classList.add('hidden'); document.body.classList.remove('has-player'); return; }
  const item = getItem(player.key); const s = subj(item.subjectId);
  bar.classList.remove('hidden'); document.body.classList.add('has-player');
  bar.innerHTML = `
    <div class="flex items-center gap-3 px-3 sm:px-4 h-full max-w-6xl mx-auto">
      <a href="#/podcast/${player.key}" class="flex items-center gap-3 min-w-0 flex-1">
        <div class="w-10 h-10 rounded-lg grid place-items-center shrink-0" style="background:${s.soft};color:${s.color}">${icon('podcast', 'w-5 h-5')}</div>
        <div class="min-w-0">
          <div class="text-sm font-semibold truncate">${esc(item.title)}</div>
          <div class="text-xs text-slate-500 truncate" id="pl-seg"></div>
        </div>
      </a>
      <div class="flex items-center gap-1">
        <button class="icon-btn hidden sm:grid" data-pl="prev" title="Précédent">${icon('skip-back')}</button>
        <button class="play-btn" data-pl="toggle" title="Lecture / pause" id="pl-toggle"></button>
        <button class="icon-btn" data-pl="next" title="Suivant">${icon('skip-forward')}</button>
        <button class="chip-btn hidden sm:inline-flex" data-pl="rate" id="pl-rate">${player.rate}×</button>
        <button class="icon-btn" data-pl="close" title="Fermer">${icon('x')}</button>
      </div>
    </div>
    <div class="absolute left-0 right-0 top-0 h-0.5 bg-slate-100"><div id="pl-prog" class="h-full" style="background:${s.color};width:0"></div></div>`;
  syncPlayer();
}
function syncPlayer() {
  if (player.key) {
    const seg = player.segs[player.idx];
    const t = $('#pl-toggle');
    if (t) { t.innerHTML = icon(player.playing ? 'pause' : 'play', 'w-5 h-5'); paintIcons(); }
    const sl = $('#pl-seg'); if (sl) sl.textContent = `${seg?.label || ''} · ${player.idx + 1}/${player.segs.length}${player.narrator?.mode === 'ai' ? ' · Voix IA' : ''}`;
    const pr = $('#pl-prog'); if (pr) pr.style.width = `${((player.idx + 1) / player.segs.length) * 100}%`;
  }
  // transcript highlight
  $$('[data-seg]').forEach((el) => {
    const on = player.key === el.dataset.key && Number(el.dataset.seg) === player.idx;
    el.classList.toggle('seg-active', on);
    if (on && player.playing && el.dataset.autoscroll !== '0') el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  });
  $$('[data-podplay]').forEach((el) => {
    const on = el.dataset.podplay === player.key && player.playing;
    el.innerHTML = icon(on ? 'pause' : 'play', el.dataset.size === 'lg' ? 'w-6 h-6' : 'w-4 h-4');
  });
  if (typeof listenBtnUpdater === 'function') listenBtnUpdater();
  paintIcons();
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-pl]');
  if (b) {
    const a = b.dataset.pl;
    if (a === 'toggle') player.narrator?.toggle();
    if (a === 'next') player.narrator?.next();
    if (a === 'prev') player.narrator?.prev();
    if (a === 'close') stopPodcast();
    if (a === 'rate') {
      const rates = [1, 1.25, 1.5, 0.75]; player.rate = rates[(rates.indexOf(player.rate) + 1) % rates.length];
      player.narrator?.setRate(player.rate); b.textContent = player.rate + '×';
    }
    return;
  }
  const pp = e.target.closest('[data-podplay]');
  if (pp) {
    e.preventDefault();
    const k = pp.dataset.podplay;
    if (player.key === k) player.narrator.toggle(); else startPodcast(k);
    return;
  }
  const sg = e.target.closest('[data-seg]');
  if (sg) {
    const k = sg.dataset.key, i = Number(sg.dataset.seg);
    if (player.key === k) player.narrator.play(i); else startPodcast(k, i);
    return;
  }
  const vd = e.target.closest('[data-video]');
  if (vd) { e.preventDefault(); openVideo(vd.dataset.video); return; }
  const yt = e.target.closest('[data-yt]');
  if (yt) { e.preventDefault(); openYouTube(yt.dataset.yt, yt.dataset.title); return; }
  const dn = e.target.closest('[data-done]');
  if (dn) {
    toggleDone(dn.dataset.done).then(() => {
      if (!isSignedIn()) toast('Connectez-vous pour sauvegarder votre progression.');
      render();
    });
  }
});

// ================= VIDEO PLAYER =================
const video = { open: false, slides: [], i: 0, playing: false, sound: true, narrator: null, timer: null, item: null, s: null };

function openVideo(key) {
  const item = getItem(key); if (!item) return;
  if (player.playing) player.narrator.pause();
  const s = subj(item.subjectId);
  Object.assign(video, { open: true, item, s, slides: videoSlides(item, s.name), i: 0, playing: false });
  video.narrator = new Narrator(video.slides.map((x) => ({ text: x.narration })), {
    onSegment: (i) => { video.i = i; drawSlide(); },
    onState: (p) => { video.playing = p; drawVideoControls(); },
    onEnd: () => { video.playing = false; drawVideoControls(); },
    onError: (e) => { toast(e.message, 'err'); },
  });
  const m = $('#modal');
  m.innerHTML = `
    <div class="modal-card max-w-4xl">
      <div class="flex items-center justify-between px-4 py-3 border-b border-slate-100">
        <div class="min-w-0"><div class="text-xs font-medium" style="color:${s.color}">${esc(s.name)} · Résumé vidéo</div>
        <div class="font-semibold truncate">${esc(item.title)}</div></div>
        <button class="icon-btn" id="v-close" title="Fermer">${icon('x')}</button>
      </div>
      <div class="p-3 sm:p-4">
        <div id="v-stage" class="stage" style="--c:${s.color};--soft:${s.soft}"></div>
        <div id="v-bars" class="flex gap-1 mt-3">${video.slides.map((_, i) => `<button class="vbar" data-vgo="${i}"><span></span></button>`).join('')}</div>
        <div class="flex items-center justify-between mt-3">
          <div class="flex items-center gap-1">
            <button class="icon-btn" id="v-prev" title="Diapo précédente">${icon('skip-back')}</button>
            <button class="play-btn" id="v-toggle"></button>
            <button class="icon-btn" id="v-next" title="Diapo suivante">${icon('skip-forward')}</button>
            <span class="text-xs text-slate-500 ml-2" id="v-count"></span>
          </div>
          <div class="flex items-center gap-1">
            <button class="icon-btn" id="v-sound" title="Narration"></button>
            <button class="icon-btn" id="v-full" title="Plein écran">${icon('maximize')}</button>
          </div>
        </div>
      </div>
    </div>`;
  m.classList.remove('hidden');
  drawSlide(); drawVideoControls();
  $('#v-close').onclick = closeVideo;
  $('#v-toggle').onclick = () => videoToggle();
  $('#v-next').onclick = () => videoGo(Math.min(video.i + 1, video.slides.length - 1));
  $('#v-prev').onclick = () => videoGo(Math.max(video.i - 1, 0));
  $('#v-sound').onclick = () => { const was = video.playing; videoPause(); video.sound = !video.sound; drawVideoControls(); if (was) videoPlay(); };
  $('#v-full').onclick = () => { const st = $('#v-stage'); (document.fullscreenElement ? document.exitFullscreen() : st.requestFullscreen?.())?.catch?.(() => {}); };
  $$('[data-vgo]').forEach((b) => (b.onclick = () => videoGo(Number(b.dataset.vgo))));
  videoPlay();
}
function videoPlay() {
  if (video.sound) video.narrator.play(video.i);
  else { video.playing = true; drawVideoControls(); scheduleTimer(); }
}
function scheduleTimer() {
  clearTimeout(video.timer);
  const sl = video.slides[video.i];
  const ms = Math.max(3500, (sl.narration || '').split(/\s+/).length * 400);
  video.timer = setTimeout(() => {
    if (video.i < video.slides.length - 1) { video.i++; drawSlide(); scheduleTimer(); }
    else { video.playing = false; drawVideoControls(); }
  }, ms);
}
function videoPause() { clearTimeout(video.timer); video.narrator?.pause(); video.playing = false; drawVideoControls(); }
function videoToggle() {
  if (video.playing) videoPause();
  else { if (video.i >= video.slides.length - 1 && !video.playing) video.i = video.i; videoPlay(); }
}
function videoGo(i) {
  const was = video.playing; videoPause(); video.i = i; drawSlide();
  if (was) videoPlay();
}
function closeVideo() {
  if (!video.open) return;
  clearTimeout(video.timer); video.narrator?.stop(); video.open = false;
  const m = $('#modal'); m.classList.add('hidden'); m.innerHTML = '';
}
function drawVideoControls() {
  const t = $('#v-toggle'); if (!t) return;
  t.innerHTML = icon(video.playing ? 'pause' : 'play', 'w-5 h-5');
  $('#v-sound').innerHTML = icon(video.sound ? 'volume-2' : 'volume-x');
  paintIcons();
}
function drawSlide() {
  const st = $('#v-stage'); if (!st) return;
  const sl = video.slides[video.i];
  let html = '';
  if (sl.type === 'title' || sl.type === 'end') {
    html = `<div class="slide center"><div class="slide-badge">${icon(sl.type === 'end' ? 'graduation-cap' : video.s.icon, 'w-7 h-7')}</div>
      <h2 class="slide-title">${esc(sl.title)}</h2><p class="slide-sub">${esc(sl.sub)}</p></div>`;
  } else if (sl.type === 'text') {
    html = `<div class="slide"><div class="slide-h">${esc(sl.heading)}</div><p class="slide-body">${esc(sl.body)}</p></div>`;
  } else if (sl.type === 'point') {
    html = `<div class="slide"><div class="slide-h">${esc(sl.heading)} <span class="opacity-60">/ ${sl.total}</span></div>
      <div class="flex gap-4 items-start"><div class="slide-num">${sl.index}</div><p class="slide-body big">${esc(sl.body)}</p></div></div>`;
  } else if (sl.type === 'list') {
    html = `<div class="slide"><div class="slide-h">${esc(sl.heading)}</div><ul class="slide-list">${sl.items.map((x) => `<li>${icon('check', 'w-5 h-5 shrink-0')}<span>${esc(x)}</span></li>`).join('')}</ul></div>`;
  } else if (sl.type === 'formulas') {
    html = `<div class="slide"><div class="slide-h">${esc(sl.heading)}</div><div class="grid gap-2">${sl.items.slice(0, 6).map((f) => `<div class="slide-formula">${esc(f)}</div>`).join('')}</div></div>`;
  } else if (sl.type === 'terms') {
    html = `<div class="slide"><div class="slide-h">${esc(sl.heading)}</div><div class="grid gap-2.5">${sl.items.map(([t, d]) => `<div class="slide-term"><b>${esc(t)}</b><span>${esc(d)}</span></div>`).join('')}</div></div>`;
  }
  st.innerHTML = html + `<div class="stage-foot"><span>${esc(video.s.name)}</span><span>ISET Nabeul</span></div>`;
  $$('#v-bars .vbar').forEach((b, i) => b.classList.toggle('done', i <= video.i));
  const c = $('#v-count'); if (c) c.textContent = `${video.i + 1} / ${video.slides.length}`;
  paintIcons();
}
function openYouTube(id, title) {
  if (player.playing) player.narrator.pause();
  const m = $('#modal');
  m.innerHTML = `<div class="modal-card max-w-4xl">
    <div class="flex items-center justify-between px-4 py-3 border-b border-slate-100"><div class="font-semibold truncate">${esc(title || 'Vidéo')}</div>
    <button class="icon-btn" id="yt-close">${icon('x')}</button></div>
    <div class="p-3"><div class="aspect-video rounded-xl overflow-hidden bg-black"><iframe class="w-full h-full" src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1" allow="autoplay; encrypted-media; fullscreen" allowfullscreen></iframe></div></div></div>`;
  m.classList.remove('hidden'); paintIcons();
  $('#yt-close').onclick = () => { m.classList.add('hidden'); m.innerHTML = ''; };
}
$('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') { if (video.open) closeVideo(); else { e.currentTarget.classList.add('hidden'); e.currentTarget.innerHTML = ''; } } });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#modal').classList.contains('hidden')) { if (video.open) closeVideo(); else { $('#modal').classList.add('hidden'); $('#modal').innerHTML = ''; } } });

// ================= VUES =================
const view = () => $('#view');

function pageHead(title, sub, actions = '') {
  return `<div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
    <div><h1 class="text-2xl font-bold tracking-tight">${title}</h1>${sub ? `<p class="text-slate-500 mt-1">${sub}</p>` : ''}</div>${actions}</div>`;
}
function itemRow(it, { showSubject = true } = {}) {
  const s = subj(it.subjectId); const done = state.progress.has(it.key);
  return `<a href="${it.href}" class="row">
    <div class="w-10 h-10 rounded-lg grid place-items-center shrink-0" style="background:${s.soft};color:${s.color}">${icon(it.kind === 'tp' ? 'flask-conical' : it.imported ? 'file-text' : 'book-open', 'w-5 h-5')}</div>
    <div class="min-w-0 flex-1"><div class="font-medium truncate">${it.kind === 'tp' && it.num ? `TP ${it.num} · ` : ''}${esc(it.title)}</div>
    <div class="text-xs text-slate-500 truncate">${showSubject ? esc(s.name) + ' · ' : ''}${it.kind === 'tp' ? 'Travaux pratiques' : 'Cours'}${it.duration ? ' · ' + esc(it.duration) : ''}${it.imported ? ' · Importé' : ''}</div></div>
    ${done ? `<span class="text-emerald-600" title="Révisé">${icon('circle-check', 'w-5 h-5')}</span>` : icon('chevron-right', 'w-4 h-4 text-slate-300')}
  </a>`;
}

function viewHome() {
  const total = SUBJECTS.reduce((n, s) => n + s.chapters.length, 0);
  const name = state.user?.username;
  view().innerHTML = `
    <section class="hero">
      <div class="max-w-xl">
        <div class="inline-flex items-center gap-2 text-xs font-medium bg-white/10 rounded-full px-3 py-1 mb-4">${icon('graduation-cap', 'w-3.5 h-3.5')} ISET Nabeul · Révisions</div>
        <h1 class="text-3xl sm:text-4xl font-bold tracking-tight">${name ? `Bonjour ${esc(name)},` : 'Révisez plus vite,'}<br>${name ? 'prêt à réviser ?' : 'retenez mieux.'}</h1>
        <p class="text-emerald-50/80 mt-3">Résumés de cours, TP guidés, podcasts et vidéos pour Digital Skills, Fondamentaux IT et Systèmes électriques. Importez vos supports depuis Google Classroom.</p>
        <div class="relative mt-6">
          ${icon('search', 'w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400')}
          <input id="search" type="search" placeholder="Rechercher un cours, un TP, une notion…" class="w-full h-12 rounded-xl pl-10 pr-4 text-slate-900 outline-none focus:ring-2 focus:ring-emerald-300" />
        </div>
      </div>
      <div class="grid grid-cols-4 gap-2 sm:gap-3 mt-8 max-w-xl">
        ${[[total, 'Résumés'], [TPS.length, 'TP'], [total + TPS.length + state.imported.length, 'Podcasts'], [total + TPS.length + state.imported.length, 'Vidéos']].map(([n, l]) => `<div class="stat"><div class="text-xl sm:text-2xl font-bold">${n}</div><div class="text-[11px] sm:text-xs text-emerald-50/70">${l}</div></div>`).join('')}
      </div>
    </section>
    <div id="search-results" class="hidden mt-6"></div>
    <div id="home-main">
      <h2 class="section-title">Matières</h2>
      <div class="grid sm:grid-cols-3 gap-4">
        ${SUBJECTS.map((s) => {
          const keys = s.chapters.map((c) => `c~${s.id}~${c.id}`).concat(TPS.filter((t) => t.subject === s.id).map((t) => `t~${t.id}`));
          const d = keys.filter((k) => state.progress.has(k)).length; const pct = Math.round((d / keys.length) * 100);
          return `<a href="#/matiere/${s.id}" class="card card-hover p-5 flex flex-col">
            <div class="w-11 h-11 rounded-xl grid place-items-center" style="background:${s.soft};color:${s.color}">${icon(s.icon, 'w-5 h-5')}</div>
            <div class="font-semibold mt-4">${s.name}</div>
            <p class="text-sm text-slate-500 mt-1 line-clamp-2 flex-1">${s.desc}</p>
            <div class="flex items-center justify-between text-xs text-slate-500 mt-4"><span>${s.chapters.length} chapitres · ${TPS.filter((t) => t.subject === s.id).length} TP</span><span>${pct}%</span></div>
            <div class="h-1.5 rounded-full bg-slate-100 mt-2 overflow-hidden"><div class="h-full rounded-full" style="width:${pct}%;background:${s.color}"></div></div>
          </a>`;
        }).join('')}
      </div>

      <div class="grid lg:grid-cols-3 gap-4 mt-8">
        <a href="#/classroom" class="card card-hover p-5 flex items-start gap-4 lg:col-span-1">
          <div class="w-11 h-11 rounded-xl grid place-items-center bg-emerald-50 text-emerald-700 shrink-0">${icon('school', 'w-5 h-5')}</div>
          <div><div class="font-semibold">Google Classroom</div><p class="text-sm text-slate-500 mt-1">${GC.isConnected() ? 'Connecté. Parcourez vos classes et importez les supports.' : 'Reliez votre compte pour importer les cours et TP de vos enseignants.'}</p></div>
        </a>
        <a href="#/import" class="card card-hover p-5 flex items-start gap-4">
          <div class="w-11 h-11 rounded-xl grid place-items-center bg-sky-50 text-sky-700 shrink-0">${icon('file-up', 'w-5 h-5')}</div>
          <div><div class="font-semibold">Importer un cours</div><p class="text-sm text-slate-500 mt-1">PDF, Word ou texte : obtenez un résumé, un podcast et une vidéo automatiquement.</p></div>
        </a>
        <a href="#/podcasts" class="card card-hover p-5 flex items-start gap-4">
          <div class="w-11 h-11 rounded-xl grid place-items-center bg-amber-50 text-amber-700 shrink-0">${icon('headphones', 'w-5 h-5')}</div>
          <div><div class="font-semibold">Réviser en écoutant</div><p class="text-sm text-slate-500 mt-1">Chaque résumé existe en podcast, à écouter dans le bus ou à la maison.</p></div>
        </a>
      </div>

      ${state.imported.length ? `<h2 class="section-title">Mes cours importés</h2><div class="card divide-y divide-slate-100">${state.imported.slice(0, 5).map((c) => itemRow(getItem('i~' + c.id))).join('')}</div>` : ''}

      <h2 class="section-title">TP à préparer</h2>
      <div class="card divide-y divide-slate-100">${TPS.filter((t) => !state.progress.has('t~' + t.id)).slice(0, 5).map((t) => itemRow(getItem('t~' + t.id))).join('') || '<div class="p-5 text-sm text-slate-500">Tous les TP sont marqués comme révisés. Bravo !</div>'}</div>
    </div>`;
  const input = $('#search');
  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    const box = $('#search-results'), main = $('#home-main');
    if (!q) { box.classList.add('hidden'); main.classList.remove('hidden'); return; }
    const res = allItems().filter((it) => [it.title, it.summary, ...(it.points || []), ...(it.steps || []), ...(it.terms || []).flat()].join(' ').toLowerCase().includes(q));
    main.classList.add('hidden'); box.classList.remove('hidden');
    box.innerHTML = `<h2 class="section-title !mt-0">${res.length} résultat${res.length > 1 ? 's' : ''}</h2>` + (res.length ? `<div class="card divide-y divide-slate-100">${res.map((r) => itemRow(r)).join('')}</div>` : `<div class="empty">${icon('search-x', 'w-6 h-6')}<p>Aucun résultat pour « ${esc(q)} ».</p></div>`);
    paintIcons();
  });
}

function viewSubject(sid) {
  const s = getSubject(sid); if (!s) return notFound();
  const tps = TPS.filter((t) => t.subject === sid);
  const imp = state.imported.filter((c) => c.subjectId === sid);
  view().innerHTML = `
    <a href="#/" class="back">${icon('arrow-left')} Accueil</a>
    <div class="flex items-start gap-4 mb-8">
      <div class="w-14 h-14 rounded-2xl grid place-items-center shrink-0" style="background:${s.soft};color:${s.color}">${icon(s.icon, 'w-7 h-7')}</div>
      <div><h1 class="text-2xl font-bold tracking-tight">${s.name}</h1><p class="text-slate-500 mt-1 max-w-2xl">${s.desc}</p></div>
    </div>
    <h2 class="section-title !mt-0">Résumés de cours</h2>
    <div class="grid sm:grid-cols-2 gap-3">
      ${s.chapters.map((c, i) => {
        const k = `c~${sid}~${c.id}`; const done = state.progress.has(k);
        return `<div class="card p-4 flex flex-col">
          <a href="#/cours/${sid}/${c.id}" class="flex gap-3 items-start group">
            <div class="chap-num" style="color:${s.color};background:${s.soft}">${i + 1}</div>
            <div class="min-w-0 flex-1"><div class="font-medium group-hover:underline">${c.title}</div><div class="text-xs text-slate-500 mt-0.5">${c.duration} de lecture${done ? ' · <span class="text-emerald-600 font-medium">Révisé</span>' : ''}</div></div>
          </a>
          <div class="flex gap-2 mt-4">
            <a href="#/cours/${sid}/${c.id}" class="btn-soft flex-1">${icon('book-open')} Lire</a>
            <button class="btn-soft" data-podplay="${k}" title="Écouter">${icon('play')}</button>
            <button class="btn-soft" data-video="${k}" title="Vidéo">${icon('clapperboard')}</button>
          </div>
        </div>`;
      }).join('')}
    </div>
    <h2 class="section-title">Travaux pratiques</h2>
    <div class="card divide-y divide-slate-100">${tps.map((t) => itemRow(getItem('t~' + t.id), { showSubject: false })).join('')}</div>
    ${imp.length ? `<h2 class="section-title">Mes cours importés</h2><div class="card divide-y divide-slate-100">${imp.map((c) => itemRow(getItem('i~' + c.id), { showSubject: false })).join('')}</div>` : ''}`;
  syncPlayer();
}

function actionBar(it) {
  const done = state.progress.has(it.key);
  return `<div class="flex flex-wrap gap-2 mt-5">
    <button class="btn-primary" data-podplay-btn="${it.key}" id="listen-btn">${icon('headphones')} Écouter le podcast</button>
    <button class="btn-outline" data-video="${it.key}">${icon('clapperboard')} Voir la vidéo</button>
    <button class="btn-outline ${done ? 'is-done' : ''}" data-done="${it.key}">${icon(done ? 'circle-check' : 'circle')} ${done ? 'Révisé' : 'Marquer comme révisé'}</button>
  </div>`;
}
function bindListen(it) {
  const b = $('#listen-btn'); if (b) b.onclick = () => { if (player.key === it.key) player.narrator.toggle(); else startPodcast(it.key); };
}
function sectionList(title, ic, items, numbered = false) {
  if (!items?.length) return '';
  return `<section class="card p-5 sm:p-6"><h2 class="sec-h">${icon(ic)} ${title}</h2>
    <ol class="mt-4 space-y-3">${items.map((p, i) => `<li class="flex gap-3">${numbered ? `<span class="num">${i + 1}</span>` : `<span class="dot"></span>`}<span class="text-slate-700 leading-relaxed">${esc(p)}</span></li>`).join('')}</ol></section>`;
}
function formulasBlock(f) {
  if (!f?.length) return '';
  return `<section class="card p-5 sm:p-6"><h2 class="sec-h">${icon('sigma')} Formules et commandes</h2>
    <div class="grid sm:grid-cols-2 gap-2 mt-4">${f.map((x) => `<code class="formula">${esc(x)}</code>`).join('')}</div></section>`;
}
function termsBlock(t) {
  if (!t?.length) return '';
  return `<section class="card p-5 sm:p-6"><h2 class="sec-h">${icon('book-a')} Vocabulaire</h2>
    <dl class="mt-4 grid gap-3">${t.map(([a, b]) => `<div class="term"><dt>${esc(a)}</dt><dd>${esc(b)}</dd></div>`).join('')}</dl></section>`;
}
function detailShell(it, extraTop, body, backHref, backLabel) {
  const s = subj(it.subjectId);
  view().innerHTML = `
    <a href="${backHref}" class="back">${icon('arrow-left')} ${esc(backLabel)}</a>
    <header class="mb-6">
      <div class="flex flex-wrap items-center gap-2 text-xs font-medium">
        <span class="pill" style="background:${s.soft};color:${s.color}">${icon(s.icon, 'w-3.5 h-3.5')} ${esc(s.name)}</span>
        <span class="pill bg-slate-100 text-slate-600">${it.kind === 'tp' ? 'Travaux pratiques' : 'Résumé de cours'}</span>
        ${it.duration ? `<span class="pill bg-slate-100 text-slate-600">${icon('clock', 'w-3.5 h-3.5')} ${esc(it.duration)}</span>` : ''}
        ${it.imported ? `<span class="pill bg-sky-50 text-sky-700">${icon(it.source === 'classroom' ? 'school' : 'file-up', 'w-3.5 h-3.5')} ${it.source === 'classroom' ? 'Google Classroom' : 'Importé'}</span>` : ''}
      </div>
      <h1 class="text-2xl sm:text-3xl font-bold tracking-tight mt-3">${it.kind === 'tp' && it.num ? `TP ${it.num} — ` : ''}${esc(it.title)}</h1>
      ${extraTop || ''}
      ${actionBar(it)}
    </header>
    <div class="grid gap-4">${body}</div>`;
  bindListen(it);
  const lb = $('#listen-btn');
  const upd = () => { if (lb) lb.innerHTML = `${icon(player.key === it.key && player.playing ? 'pause' : 'headphones')} ${player.key === it.key && player.playing ? 'Pause' : 'Écouter le podcast'}`; paintIcons(); };
  upd(); listenBtnUpdater = upd;
}
let listenBtnUpdater = null;

function viewChapter(sid, cid) {
  const it = getItem(`c~${sid}~${cid}`); if (!it) return notFound();
  const s = subj(sid);
  const idx = s.chapters.findIndex((c) => c.id === cid);
  const prev = s.chapters[idx - 1], next = s.chapters[idx + 1];
  detailShell(it, '', `
    <section class="card p-5 sm:p-6"><h2 class="sec-h">${icon('sparkles')} L'essentiel</h2><p class="mt-3 text-slate-700 leading-relaxed text-[15px]">${esc(it.summary)}</p></section>
    ${sectionList('Points clés', 'list-checks', it.points, true)}
    ${formulasBlock(it.formulas)}
    ${termsBlock(it.terms)}
    <div class="grid sm:grid-cols-2 gap-3">
      ${prev ? `<a href="#/cours/${sid}/${prev.id}" class="card card-hover p-4"><div class="text-xs text-slate-500">Précédent</div><div class="font-medium mt-0.5">${prev.title}</div></a>` : '<div></div>'}
      ${next ? `<a href="#/cours/${sid}/${next.id}" class="card card-hover p-4 sm:text-right"><div class="text-xs text-slate-500">Suivant</div><div class="font-medium mt-0.5">${next.title}</div></a>` : ''}
    </div>`, `#/matiere/${sid}`, s.name);
}

function viewTP(id) {
  const it = getItem(`t~${id}`); if (!it) return notFound();
  detailShell(it, `<p class="text-slate-500 mt-2">Durée de la séance : ${esc(it.duration)}</p>`, `
    <div class="grid md:grid-cols-2 gap-4">
      ${sectionList('Objectifs', 'target', it.objectives)}
      ${sectionList('Matériel', 'wrench', it.materiel)}
    </div>
    ${sectionList('Manipulation', 'list-ordered', it.steps, true)}
    ${sectionList('Questions de compréhension', 'circle-help', it.questions)}
    ${it.tip ? `<section class="tip">${icon('lightbulb', 'w-5 h-5 shrink-0')}<div><div class="font-semibold">Astuce</div><p class="mt-1">${esc(it.tip)}</p></div></section>` : ''}
  `, '#/tp', 'Travaux pratiques');
}

function viewImported(id) {
  const it = getItem(`i~${id}`);
  if (!it) {
    if (!state.ready) { view().innerHTML = loading(); return; }
    return notFound(isSignedIn() ? 'Ce cours importé est introuvable.' : 'Connectez-vous pour voir vos cours importés.');
  }
  detailShell(it, it.sourceName ? `<p class="text-slate-500 mt-2 text-sm">Source : ${esc(it.sourceName)}</p>` : '', `
    <section class="card p-5 sm:p-6"><h2 class="sec-h">${icon('sparkles')} L'essentiel</h2><p class="mt-3 text-slate-700 leading-relaxed text-[15px]">${esc(it.summary)}</p></section>
    ${sectionList(it.kind === 'tp' ? 'Étapes et consignes' : 'Points clés', 'list-checks', it.points, true)}
    ${formulasBlock(it.formulas)}
    ${termsBlock(it.terms)}
    <div><button class="btn-danger" id="del-imp">${icon('trash-2')} Supprimer ce cours</button></div>
  `, '#/import', 'Mes imports');
  $('#del-imp').onclick = async () => {
    if (!confirm('Supprimer ce cours importé ?')) return;
    try { if (player.key === it.key) stopPodcast(); await deleteImported(id); toast('Cours supprimé.'); location.hash = '#/import'; }
    catch (e) { toast(e.message || 'Suppression impossible', 'err'); }
  };
}

let tpFilter = 'all';
function viewTPList() {
  const list = TPS.filter((t) => tpFilter === 'all' || t.subject === tpFilter);
  view().innerHTML = pageHead('Travaux pratiques', 'Les TP de l\'ISET Nabeul : objectifs, matériel, manipulation et questions.') + `
    <div class="tabs mb-5">${[['all', 'Tous'], ...SUBJECTS.map((s) => [s.id, s.name])].map(([id, n]) => `<button class="tab ${tpFilter === id ? 'active' : ''}" data-tpf="${id}">${n}</button>`).join('')}</div>
    <div class="grid md:grid-cols-2 gap-4">
      ${list.map((t) => {
        const s = subj(t.subject); const k = 't~' + t.id; const done = state.progress.has(k);
        return `<div class="card p-5 flex flex-col">
          <div class="flex items-center justify-between"><span class="pill" style="background:${s.soft};color:${s.color}">${icon(s.icon, 'w-3.5 h-3.5')} ${s.name} · TP ${t.num}</span>
          ${done ? `<span class="text-emerald-600 text-xs font-medium flex items-center gap-1">${icon('circle-check', 'w-4 h-4')} Révisé</span>` : `<span class="text-xs text-slate-500">${t.duration}</span>`}</div>
          <a href="#/tp/${t.id}" class="font-semibold mt-3 hover:underline">${t.title}</a>
          <ul class="text-sm text-slate-500 mt-2 space-y-1 flex-1">${t.objectives.slice(0, 2).map((o) => `<li class="flex gap-2"><span class="dot mt-2"></span>${o}</li>`).join('')}</ul>
          <div class="flex gap-2 mt-4">
            <a href="#/tp/${t.id}" class="btn-soft flex-1">${icon('flask-conical')} Ouvrir le TP</a>
            <button class="btn-soft" data-podplay="${k}" title="Écouter">${icon('play')}</button>
            <button class="btn-soft" data-video="${k}" title="Vidéo">${icon('clapperboard')}</button>
          </div></div>`;
      }).join('')}
    </div>`;
  $$('[data-tpf]').forEach((b) => (b.onclick = () => { tpFilter = b.dataset.tpf; viewTPList(); paintIcons(); syncPlayer(); }));
  syncPlayer();
}

let podFilter = 'all';
function filterTabs(current, attr) {
  const tabs = [['all', 'Tous'], ...SUBJECTS.map((s) => [s.id, s.name]), ['tp', 'TP'], ['mine', 'Mes imports']];
  return `<div class="tabs mb-5">${tabs.map(([id, n]) => `<button class="tab ${current === id ? 'active' : ''}" data-${attr}="${id}">${n}</button>`).join('')}</div>`;
}
function filterItems(f) {
  return allItems().filter((it) => f === 'all' || (f === 'tp' ? it.kind === 'tp' && !it.imported : f === 'mine' ? it.imported : it.subjectId === f && it.kind !== 'tp' && !it.imported));
}
function voiceSelector() {
  const ai = state.voiceMode === 'ai';
  return `<div class="card p-1 inline-flex text-sm">
    <button class="seg ${!ai ? 'active' : ''}" data-voice="browser">${icon('volume-2')} Voix standard</button>
    <button class="seg ${ai ? 'active' : ''}" data-voice="ai">${icon('sparkles')} Voix IA naturelle</button></div>`;
}
function bindVoice() {
  $$('[data-voice]').forEach((b) => (b.onclick = async () => {
    const m = b.dataset.voice;
    if (m === 'ai' && !isSignedIn()) {
      try { await signIn(); } catch (e) { return; }
    }
    await setVoiceMode(m);
    if (player.narrator && player.playing) player.narrator.play(player.idx);
    render();
    toast(m === 'ai' ? 'Voix IA activée.' : 'Voix standard activée.');
  }));
}
function viewPodcasts() {
  const list = filterItems(podFilter);
  view().innerHTML = pageHead('Podcasts', 'Chaque résumé lu à voix haute, épisode par épisode.', voiceSelector()) + filterTabs(podFilter, 'podf') + `
    ${list.length ? `<div class="card divide-y divide-slate-100">${list.map((it) => {
      const s = subj(it.subjectId); const segs = podcastScript(it, s.name, it.kind);
      return `<div class="flex items-center gap-3 p-3 sm:p-4">
        <button class="pod-play" data-podplay="${it.key}" style="background:${s.soft};color:${s.color}">${icon('play')}</button>
        <a href="#/podcast/${it.key}" class="min-w-0 flex-1"><div class="font-medium truncate">${it.kind === 'tp' && it.num ? `TP ${it.num} · ` : ''}${esc(it.title)}</div>
        <div class="text-xs text-slate-500 truncate">${esc(s.name)} · ${segs.length} parties · env. ${minutesOf(segs)} min</div></a>
        <a href="#/podcast/${it.key}" class="icon-btn" title="Transcription">${icon('file-text')}</a>
      </div>`;
    }).join('')}</div>` : emptyMine()}`;
  $$('[data-podf]').forEach((b) => (b.onclick = () => { podFilter = b.dataset.podf; viewPodcasts(); paintIcons(); }));
  bindVoice(); syncPlayer();
}
function viewPodcastDetail(key) {
  const it = getItem(key); if (!it) return state.ready ? notFound() : (view().innerHTML = loading());
  const s = subj(it.subjectId); const segs = podcastScript(it, s.name, it.kind);
  view().innerHTML = `
    <a href="#/podcasts" class="back">${icon('arrow-left')} Podcasts</a>
    <div class="card p-5 sm:p-6 flex flex-col sm:flex-row gap-5 sm:items-center">
      <div class="w-24 h-24 rounded-2xl grid place-items-center shrink-0" style="background:${s.soft};color:${s.color}">${icon('podcast', 'w-10 h-10')}</div>
      <div class="flex-1 min-w-0">
        <div class="text-xs font-medium" style="color:${s.color}">${esc(s.name)} · Épisode</div>
        <h1 class="text-xl sm:text-2xl font-bold tracking-tight mt-1">${esc(it.title)}</h1>
        <p class="text-sm text-slate-500 mt-1">${segs.length} parties · environ ${minutesOf(segs)} min</p>
      </div>
      <button class="pod-play lg" data-podplay="${key}" data-size="lg" style="background:${s.color};color:#fff">${icon('play', 'w-6 h-6')}</button>
    </div>
    <div class="flex flex-wrap items-center justify-between gap-3 mt-6 mb-3"><h2 class="font-semibold">Transcription</h2>${voiceSelector()}</div>
    <div class="card divide-y divide-slate-100">${segs.map((g, i) => `<button class="seg-row" data-seg="${i}" data-key="${key}"><span class="seg-label">${esc(g.label)}</span><span class="text-slate-700 text-left leading-relaxed">${esc(g.text)}</span></button>`).join('')}</div>
    <div class="flex gap-2 mt-4"><a href="${it.href}" class="btn-outline">${icon('book-open')} Lire le résumé</a><button class="btn-outline" data-video="${key}">${icon('clapperboard')} Voir la vidéo</button></div>`;
  bindVoice(); syncPlayer();
}

let vidFilter = 'all';
let classroomVideos = [];
function thumb(it) {
  const s = subj(it.subjectId);
  return `<div class="thumb" style="background:${s.soft};color:${s.color}">
    <div class="absolute top-3 left-3 text-[11px] font-semibold uppercase tracking-wide opacity-80">${esc(s.name)}</div>
    ${icon(it.kind === 'tp' ? 'flask-conical' : s.icon, 'w-9 h-9')}
    <div class="thumb-play">${icon('play', 'w-4 h-4')}</div>
  </div>`;
}
function viewVideos() {
  const list = filterItems(vidFilter);
  view().innerHTML = pageHead('Vidéos', 'Des résumés animés et commentés, diapositive par diapositive.') + filterTabs(vidFilter, 'vidf') + `
    ${list.length ? `<div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">${list.map((it) => {
      const n = videoSlides(it, subj(it.subjectId).name).length;
      return `<button class="text-left card card-hover overflow-hidden" data-video="${it.key}">${thumb(it)}
        <div class="p-4"><div class="font-medium line-clamp-2">${it.kind === 'tp' && it.num ? `TP ${it.num} · ` : ''}${esc(it.title)}</div><div class="text-xs text-slate-500 mt-1">${n} diapositives · narration</div></div></button>`;
    }).join('')}</div>` : emptyMine()}
    ${classroomVideos.length ? `<h2 class="section-title">Vidéos de Google Classroom</h2><div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">${classroomVideos.map((v) => `
      <button class="text-left card card-hover overflow-hidden" data-yt="${esc(v.id)}" data-title="${esc(v.title)}">
        <div class="thumb bg-slate-900">${v.thumb ? `<img src="${esc(v.thumb)}" alt="" class="absolute inset-0 w-full h-full object-cover opacity-80">` : ''}<div class="thumb-play">${icon('play', 'w-4 h-4')}</div></div>
        <div class="p-4"><div class="font-medium line-clamp-2">${esc(v.title)}</div><div class="text-xs text-slate-500 mt-1">${esc(v.course)}</div></div></button>`).join('')}</div>` : ''}`;
  $$('[data-vidf]').forEach((b) => (b.onclick = () => { vidFilter = b.dataset.vidf; viewVideos(); paintIcons(); }));
}
function emptyMine() {
  return `<div class="empty">${icon('inbox', 'w-6 h-6')}<p>Aucun cours importé pour l'instant.</p><a href="#/import" class="btn-primary mt-2">${icon('file-up')} Importer un cours</a></div>`;
}

// ---------- Import ----------
let importState = { tab: 'file', file: null, busy: false, step: '' };
function signInGate(msg) {
  return `<div class="card p-6 text-center">
    <div class="w-12 h-12 rounded-xl grid place-items-center bg-emerald-50 text-emerald-700 mx-auto">${icon('lock', 'w-5 h-5')}</div>
    <h3 class="font-semibold mt-3">Connexion requise</h3><p class="text-sm text-slate-500 mt-1 max-w-md mx-auto">${msg}</p>
    <button class="btn-primary mt-4" data-signin>${icon('log-in')} Se connecter avec Puter</button></div>`;
}
function subjectOptions() {
  return SUBJECTS.map((s) => `<option value="${s.id}">${s.name}</option>`).join('') + `<option value="autre">Autre matière</option>`;
}
function viewImport() {
  view().innerHTML = pageHead('Importer un cours ou un TP', 'Ajoutez vos supports : l\'IA en fait un résumé, un podcast et une vidéo.', `<a href="#/classroom" class="btn-outline">${icon('school')} Depuis Google Classroom</a>`) +
    (!isSignedIn() ? signInGate('Les résumés sont générés par IA et vos cours importés sont enregistrés dans votre espace personnel Puter.') : `
    <div class="grid lg:grid-cols-5 gap-4">
      <div class="lg:col-span-3 card p-5 sm:p-6">
        <div class="card p-1 inline-flex text-sm mb-5">
          <button class="seg ${importState.tab === 'file' ? 'active' : ''}" data-itab="file">${icon('file-up')} Fichier</button>
          <button class="seg ${importState.tab === 'text' ? 'active' : ''}" data-itab="text">${icon('type')} Texte</button>
          <button class="seg ${importState.tab === 'topic' ? 'active' : ''}" data-itab="topic">${icon('lightbulb')} Sujet</button>
        </div>
        <form id="imp-form" class="grid gap-4">
          ${importState.tab === 'file' ? `
            <label id="drop" class="drop">
              <input type="file" id="imp-file" accept=".pdf,.docx,.txt,.md,.csv,image/*" class="hidden">
              ${icon('upload-cloud', 'w-8 h-8 text-slate-400')}
              <div class="font-medium mt-2" id="drop-label">${importState.file ? esc(importState.file.name) : 'Glissez un fichier ici ou cliquez pour choisir'}</div>
              <div class="text-xs text-slate-500 mt-1">PDF, Word (.docx), texte ou photo du cours</div>
            </label>` : importState.tab === 'text' ? `
            <label class="field"><span>Contenu du cours</span><textarea id="imp-text" rows="9" placeholder="Collez ici le texte du cours ou du TP…"></textarea></label>` : `
            <p class="text-sm text-slate-500 -mt-1">Pas de document ? Indiquez simplement le sujet : l'IA rédige un résumé de niveau ISET.</p>`}
          <label class="field"><span>Titre ${importState.tab === 'topic' ? '/ sujet' : '(facultatif)'}</span><input id="imp-title" type="text" placeholder="${importState.tab === 'topic' ? 'Ex. Le moteur à courant continu' : 'Déduit automatiquement si vide'}"></label>
          <div class="grid sm:grid-cols-2 gap-4">
            <label class="field"><span>Matière</span><select id="imp-subject">${subjectOptions()}</select></label>
            <label class="field"><span>Type</span><select id="imp-kind"><option value="cours">Cours</option><option value="tp">TP</option></select></label>
          </div>
          <button class="btn-primary justify-center h-11" id="imp-go" type="submit" ${importState.busy ? 'disabled' : ''}>${importState.busy ? `<span class="spin"></span> ${esc(importState.step)}` : `${icon('sparkles')} Générer le résumé, le podcast et la vidéo`}</button>
        </form>
      </div>
      <div class="lg:col-span-2">
        <div class="card p-5"><h3 class="font-semibold flex items-center gap-2">${icon('folder-open')} Mes imports <span class="text-slate-400 font-normal">${state.imported.length}</span></h3>
          ${state.imported.length ? `<div class="divide-y divide-slate-100 mt-2 -mx-2">${state.imported.map((c) => itemRow(getItem('i~' + c.id))).join('')}</div>` : `<p class="text-sm text-slate-500 mt-2">Vos cours importés apparaîtront ici, ainsi que dans les podcasts et vidéos.</p>`}
        </div>
      </div>
    </div>`);
  if (!isSignedIn()) return;
  $$('[data-itab]').forEach((b) => (b.onclick = () => { importState.tab = b.dataset.itab; viewImport(); paintIcons(); }));
  const fi = $('#imp-file');
  if (fi) {
    const drop = $('#drop');
    fi.onchange = () => { importState.file = fi.files[0] || null; $('#drop-label').textContent = importState.file?.name || ''; };
    drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('drag'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('drag'));
    drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('drag'); importState.file = e.dataTransfer.files[0] || null; $('#drop-label').textContent = importState.file?.name || ''; });
  }
  $('#imp-form').onsubmit = async (e) => {
    e.preventDefault();
    if (importState.busy) return;
    const title = $('#imp-title').value.trim();
    const subjectId = $('#imp-subject').value; const kind = $('#imp-kind').value;
    let text = ''; let sourceName = '';
    const tab = importState.tab;
    if (tab === 'file' && !importState.file) return toast('Choisissez un fichier.', 'err');
    if (tab === 'text') { text = $('#imp-text').value.trim(); if (text.length < 40) return toast('Collez un texte plus long (au moins quelques phrases).', 'err'); }
    if (tab === 'topic' && !title) return toast('Indiquez le sujet du cours.', 'err');
    const setBusy = (step) => { importState.busy = !!step; importState.step = step; const b = $('#imp-go'); if (b) { b.disabled = !!step; b.innerHTML = step ? `<span class="spin"></span> ${esc(step)}` : `${icon('sparkles')} Générer le résumé, le podcast et la vidéo`; paintIcons(); } };
    try {
      if (tab === 'file') {
        setBusy('Lecture du fichier…');
        sourceName = importState.file.name;
        text = await extractText(importState.file);
        if (!text || text.length < 20) throw new Error('Aucun texte lisible trouvé dans ce fichier.');
        saveOriginalFile(importState.file);
      }
      setBusy("Rédaction du résumé par l'IA…");
      const course = await createCourse({ text, title, subjectId, kind, source: tab === 'topic' ? 'ia' : 'upload', sourceName });
      importState.file = null; setBusy('');
      toast('Résumé créé ! Podcast et vidéo prêts.');
      location.hash = `#/mes-cours/${course.id}`;
    } catch (err) { setBusy(''); toast(err.message || 'Échec de l\'import', 'err'); }
  };
}
async function createCourse({ text, title, subjectId, kind, source, sourceName }) {
  const sum = await summarize({ text, title, subjectName: subj(subjectId).name, kind });
  const course = { id: crypto.randomUUID(), kind, subjectId, source, sourceName, created: Date.now(), ...sum };
  await saveImported(course);
  return course;
}

// ---------- Google Classroom ----------
let gcState = { courses: null, course: null, items: null, loading: false, error: '' };
function viewClassroom() {
  const origin = location.origin;
  const connected = GC.isConnected();
  let body = '';
  if (!GC.gc.clientId) {
    body = `
      <div class="grid lg:grid-cols-5 gap-4">
        <div class="lg:col-span-3 card p-5 sm:p-6">
          <h2 class="font-semibold flex items-center gap-2">${icon('cloud')} Configurer Google Cloud (une seule fois)</h2>
          <ol class="steps mt-4">
            <li>Ouvrez la <a href="https://console.cloud.google.com/projectcreate" target="_blank" rel="noopener">console Google Cloud</a> et créez un projet (ex. « ISET Révisions »).</li>
            <li>Activez <a href="https://console.cloud.google.com/apis/library/classroom.googleapis.com" target="_blank" rel="noopener">Google Classroom API</a> et <a href="https://console.cloud.google.com/apis/library/drive.googleapis.com" target="_blank" rel="noopener">Google Drive API</a>.</li>
            <li>Dans <a href="https://console.cloud.google.com/auth/overview" target="_blank" rel="noopener">Google Auth Platform</a>, configurez l'écran de consentement (type « Externe ») et ajoutez votre adresse Gmail comme utilisateur test.</li>
            <li>Créez un <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener">ID client OAuth</a> de type « Application Web » et ajoutez cette origine JavaScript autorisée :
              <div class="flex gap-2 mt-2"><code class="formula flex-1 truncate">${esc(origin)}</code><button class="btn-soft" id="copy-origin" type="button">${icon('copy')}</button></div></li>
            <li>Copiez l'ID client et collez-le ci-dessous.</li>
          </ol>
          <form id="cid-form" class="flex flex-col sm:flex-row gap-2 mt-5">
            <input id="cid" class="input flex-1" placeholder="xxxxxxxx.apps.googleusercontent.com" required>
            <button class="btn-primary justify-center" type="submit">${icon('save')} Enregistrer</button>
          </form>
        </div>
        <div class="lg:col-span-2 card p-5 sm:p-6">
          <h3 class="font-semibold">Ce que vous pourrez faire</h3>
          <ul class="mt-3 space-y-3 text-sm text-slate-600">
            <li class="flex gap-3">${icon('school', 'w-4 h-4 mt-0.5 text-emerald-600 shrink-0')} Voir toutes vos classes ISET Nabeul</li>
            <li class="flex gap-3">${icon('file-down', 'w-4 h-4 mt-0.5 text-emerald-600 shrink-0')} Importer les cours et TP publiés (PDF, Docs, Slides, Word)</li>
            <li class="flex gap-3">${icon('sparkles', 'w-4 h-4 mt-0.5 text-emerald-600 shrink-0')} Obtenir un résumé, un podcast et une vidéo en un clic</li>
            <li class="flex gap-3">${icon('circle-play', 'w-4 h-4 mt-0.5 text-emerald-600 shrink-0')} Regarder les vidéos partagées par vos enseignants</li>
          </ul>
          <p class="text-xs text-slate-500 mt-4">Accès en lecture seule. Rien n'est modifié dans Classroom.</p>
        </div>
      </div>`;
  } else if (!connected) {
    body = `<div class="card p-8 text-center">
      <div class="w-14 h-14 rounded-2xl grid place-items-center bg-emerald-50 text-emerald-700 mx-auto">${icon('school', 'w-6 h-6')}</div>
      <h2 class="font-semibold text-lg mt-4">Connecter votre compte Google</h2>
      <p class="text-sm text-slate-500 mt-1 max-w-md mx-auto">Utilisez votre compte étudiant pour accéder aux classes, cours et TP publiés par vos enseignants.</p>
      <div class="flex flex-wrap gap-2 justify-center mt-5">
        <button class="btn-primary" id="gc-connect">${icon('log-in')} Se connecter avec Google</button>
        <button class="btn-outline" id="gc-reset">${icon('settings')} Changer l'ID client</button>
      </div></div>`;
  } else if (!gcState.course) {
    body = `<div class="flex items-center justify-between mb-4"><h2 class="font-semibold">Mes classes</h2>
      <div class="flex gap-2"><button class="btn-soft" id="gc-refresh">${icon('refresh-cw')} Actualiser</button><button class="btn-soft" id="gc-out">${icon('log-out')} Déconnecter</button></div></div>
      ${gcState.loading ? loading() : gcState.error ? errorBox(gcState.error) : !gcState.courses?.length ? `<div class="empty">${icon('school', 'w-6 h-6')}<p>Aucune classe active trouvée sur ce compte.</p></div>` :
      `<div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">${gcState.courses.map((c) => `
        <button class="card card-hover text-left overflow-hidden" data-gcc="${esc(c.id)}">
          <div class="h-20 bg-emerald-700 p-4 text-white"><div class="font-semibold truncate">${esc(c.name)}</div><div class="text-xs text-emerald-100 truncate">${esc(c.section || '')}</div></div>
          <div class="p-4 text-sm text-slate-500 flex items-center justify-between"><span class="truncate">${esc(c.room || c.descriptionHeading || 'Voir les supports')}</span>${icon('chevron-right', 'w-4 h-4')}</div>
        </button>`).join('')}</div>`}`;
  } else {
    const c = gcState.course;
    body = `<button class="back" id="gc-back">${icon('arrow-left')} Mes classes</button>
      <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-4">
        <div><h2 class="text-xl font-bold">${esc(c.name)}</h2><p class="text-sm text-slate-500">${esc(c.section || '')}</p></div>
        <label class="field sm:w-60"><span>Importer dans la matière</span><select id="gc-subject">${subjectOptions()}</select></label>
      </div>
      ${!isSignedIn() ? `<div class="notice mb-4">${icon('info', 'w-4 h-4 shrink-0')}<span>Connectez-vous avec Puter pour résumer et enregistrer les supports. <button class="underline font-medium" data-signin>Se connecter</button></span></div>` : ''}
      ${gcState.loading ? loading() : gcState.error ? errorBox(gcState.error) : !gcState.items?.length ? `<div class="empty">${icon('inbox', 'w-6 h-6')}<p>Aucun support publié dans cette classe.</p></div>` :
      `<div class="grid gap-3">${gcState.items.map((it, ii) => `
        <div class="card p-4 sm:p-5">
          <div class="flex items-start justify-between gap-3">
            <div class="min-w-0"><span class="pill bg-slate-100 text-slate-600">${esc(it.type)}</span>
            <div class="font-semibold mt-2">${esc(it.title)}</div>
            ${it.description ? `<p class="text-sm text-slate-500 mt-1 line-clamp-2">${esc(it.description)}</p>` : ''}</div>
            ${it.link ? `<a href="${esc(it.link)}" target="_blank" rel="noopener" class="icon-btn shrink-0" title="Ouvrir dans Classroom">${icon('external-link')}</a>` : ''}
          </div>
          <div class="grid gap-2 mt-3">
            ${it.materials.map((m, mi) => `<div class="mat">
              <span class="mat-ic">${icon(m.kind === 'drive' ? 'file-text' : m.kind === 'youtube' ? 'circle-play' : m.kind === 'form' ? 'clipboard-list' : 'link', 'w-4 h-4')}</span>
              <span class="truncate flex-1 text-sm">${esc(m.title)}</span>
              ${m.kind === 'drive' ? `<button class="btn-soft sm" data-gcimp="${ii}:${mi}">${icon('sparkles')} Résumer</button>` : ''}
              ${m.kind === 'youtube' ? `<button class="btn-soft sm" data-yt="${esc(m.id)}" data-title="${esc(m.title)}">${icon('play')} Regarder</button>` : ''}
              ${m.kind === 'link' || m.kind === 'form' ? `<a class="btn-soft sm" href="${esc(m.url)}" target="_blank" rel="noopener">${icon('external-link')} Ouvrir</a>` : ''}
            </div>`).join('')}
            ${!it.materials.length && it.description.length > 80 ? `<div class="mat"><span class="mat-ic">${icon('align-left', 'w-4 h-4')}</span><span class="flex-1 text-sm">Consigne de l'enseignant</span><button class="btn-soft sm" data-gcdesc="${ii}">${icon('sparkles')} Résumer</button></div>` : ''}
          </div>
        </div>`).join('')}</div>`}`;
  }
  view().innerHTML = pageHead('Google Classroom', 'Reliez vos classes de l\'ISET Nabeul et importez cours et TP.', connected ? `<span class="pill bg-emerald-50 text-emerald-700">${icon('circle-check', 'w-3.5 h-3.5')} Connecté</span>` : '') + body;
  bindClassroom();
}
function errorBox(msg) { return `<div class="notice notice-err">${icon('circle-alert', 'w-4 h-4 shrink-0')}<span>${esc(msg)}</span></div>`; }
async function loadCourses() {
  gcState = { ...gcState, loading: true, error: '', course: null, items: null }; viewClassroom(); paintIcons();
  try { gcState.courses = await GC.listCourses(); } catch (e) { gcState.error = e.message; }
  gcState.loading = false; if (route().startsWith('/classroom')) { viewClassroom(); paintIcons(); }
}
async function openCourse(id) {
  gcState.course = gcState.courses.find((c) => c.id === id); gcState.loading = true; gcState.error = ''; gcState.items = null;
  viewClassroom(); paintIcons();
  try {
    gcState.items = await GC.listItems(id);
    gcState.items.forEach((it) => it.materials.filter((m) => m.kind === 'youtube').forEach((m) => {
      if (!classroomVideos.some((v) => v.id === m.id)) classroomVideos.push({ id: m.id, title: m.title, thumb: m.thumb, course: gcState.course.name });
    }));
  } catch (e) { gcState.error = e.message; }
  gcState.loading = false; if (route().startsWith('/classroom')) { viewClassroom(); paintIcons(); }
}
function guessSubject(name) {
  const n = (name || '').toLowerCase();
  if (/élec|elec|électrique|electrique|machine|circuit/.test(n)) return 'elec';
  if (/digital|numérique|numerique|bureautique|skills/.test(n)) return 'digital';
  if (/it|informatique|réseau|reseau|système d|systeme d|archi/.test(n)) return 'it';
  return null;
}
function bindClassroom() {
  $('#copy-origin')?.addEventListener('click', () => { navigator.clipboard?.writeText(location.origin); toast('Origine copiée.'); });
  const f = $('#cid-form');
  if (f) f.onsubmit = async (e) => { e.preventDefault(); const v = $('#cid').value.trim(); if (!/apps\.googleusercontent\.com$/.test(v)) return toast("L'ID client doit se terminer par .apps.googleusercontent.com", 'err'); await GC.saveClientId(v); toast('ID client enregistré.'); viewClassroom(); paintIcons(); };
  $('#gc-connect')?.addEventListener('click', async () => {
    try { await GC.connect(); toast('Compte Google connecté.'); loadCourses(); } catch (e) { toast(e.message, 'err'); }
  });
  $('#gc-reset')?.addEventListener('click', async () => { await GC.saveClientId(''); viewClassroom(); paintIcons(); });
  $('#gc-refresh')?.addEventListener('click', loadCourses);
  $('#gc-out')?.addEventListener('click', () => { GC.disconnect(); gcState = { courses: null, course: null, items: null, loading: false, error: '' }; viewClassroom(); paintIcons(); });
  $('#gc-back')?.addEventListener('click', () => { gcState.course = null; gcState.items = null; gcState.error = ''; viewClassroom(); paintIcons(); });
  const sel = $('#gc-subject');
  if (sel && gcState.course) { const g = guessSubject(gcState.course.name + ' ' + (gcState.course.section || '')); if (g) sel.value = g; }
  $$('[data-gcc]').forEach((b) => (b.onclick = () => openCourse(b.dataset.gcc)));
  const runImport = async (btn, getText, title, kind, sourceName) => {
    if (!isSignedIn()) { try { await signIn(); } catch (e) { return; } }
    const orig = btn.innerHTML; btn.disabled = true; btn.innerHTML = `<span class="spin"></span> En cours…`;
    try {
      const text = await getText();
      const course = await createCourse({ text, title, subjectId: $('#gc-subject').value, kind, source: 'classroom', sourceName });
      toast('Importé et résumé !');
      location.hash = `#/mes-cours/${course.id}`;
    } catch (e) { toast(e.message || "Échec de l'import", 'err'); btn.disabled = false; btn.innerHTML = orig; paintIcons(); }
  };
  $$('[data-gcimp]').forEach((b) => (b.onclick = () => {
    const [ii, mi] = b.dataset.gcimp.split(':').map(Number); const it = gcState.items[ii]; const m = it.materials[mi];
    const kind = /tp|travaux|lab|manip/i.test(it.title + ' ' + m.title) ? 'tp' : 'cours';
    runImport(b, async () => { const r = await GC.driveText(m.id); return (it.description ? it.description + '\n\n' : '') + r.text; }, '', kind, `${gcState.course.name} · ${m.title}`);
  }));
  $$('[data-gcdesc]').forEach((b) => (b.onclick = () => {
    const it = gcState.items[Number(b.dataset.gcdesc)];
    runImport(b, async () => it.description, it.title, /tp|travaux/i.test(it.title) ? 'tp' : 'cours', `${gcState.course.name} · ${it.title}`);
  }));
}

// ---------- Divers ----------
function loading() { return `<div class="py-16 grid place-items-center text-slate-400"><span class="spin dark"></span></div>`; }
function notFound(msg = 'Page introuvable.') {
  view().innerHTML = `<div class="empty mt-10">${icon('map-pin-off', 'w-6 h-6')}<p>${esc(msg)}</p>${!isSignedIn() && msg.includes('Connectez') ? `<button class="btn-primary mt-2" data-signin>${icon('log-in')} Se connecter</button>` : `<a href="#/" class="btn-primary mt-2">Retour à l'accueil</a>`}</div>`;
}

// ---------- Shell / auth ----------
function renderAuth() {
  const html = state.user
    ? `<div class="flex items-center gap-3 p-2 rounded-xl">
        <div class="w-9 h-9 rounded-full bg-emerald-100 text-emerald-800 grid place-items-center font-semibold uppercase">${esc(state.user.username?.[0] || '?')}</div>
        <div class="min-w-0 flex-1"><div class="text-sm font-medium truncate">${esc(state.user.username)}</div><div class="text-xs text-slate-500">Progression synchronisée</div></div>
        <button class="icon-btn" data-signout title="Se déconnecter">${icon('log-out')}</button></div>`
    : `<button class="btn-primary w-full justify-center" data-signin>${icon('log-in')} Se connecter</button>
       <p class="text-xs text-slate-500 mt-2 text-center">Pour sauvegarder progression et imports</p>`;
  $('#auth-box').innerHTML = html;
  $('#auth-mobile').innerHTML = state.user
    ? `<button class="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 grid place-items-center font-semibold uppercase text-sm" data-signout title="Se déconnecter">${esc(state.user.username?.[0] || '?')}</button>`
    : `<button class="chip-btn" data-signin>${icon('log-in', 'w-3.5 h-3.5')} Connexion</button>`;
}
document.addEventListener('click', async (e) => {
  if (e.target.closest('[data-signin]')) {
    try { await signIn(); toast('Connecté.'); } catch (err) { if (err?.message) toast('Connexion annulée.', 'err'); }
  } else if (e.target.closest('[data-signout]')) {
    if (confirm('Se déconnecter ?')) { signOut(); toast('Déconnecté.'); }
  }
});

const route = () => (location.hash.replace(/^#/, '') || '/');
function setActiveNav(r) {
  const top = '/' + (r.split('/')[1] || '');
  const map = { '/': '/', '/matiere': '/', '/cours': '/', '/tp': '/tp', '/podcasts': '/podcasts', '/podcast': '/podcasts', '/videos': '/videos', '/import': '/import', '/mes-cours': '/import', '/classroom': '/classroom' };
  const a = map[top] || '/';
  $$('[data-nav]').forEach((el) => el.classList.toggle('active', el.dataset.nav === a));
}
function render() {
  const r = route(); let m;
  listenBtnUpdater = null;
  setActiveNav(r);
  if (r === '/') viewHome();
  else if ((m = r.match(/^\/matiere\/([\w-]+)$/))) viewSubject(m[1]);
  else if ((m = r.match(/^\/cours\/([\w-]+)\/([\w-]+)$/))) viewChapter(m[1], m[2]);
  else if (r === '/tp') viewTPList();
  else if ((m = r.match(/^\/tp\/([\w-]+)$/))) viewTP(m[1]);
  else if ((m = r.match(/^\/mes-cours\/([\w-]+)$/))) viewImported(m[1]);
  else if (r === '/podcasts') viewPodcasts();
  else if ((m = r.match(/^\/podcast\/(.+)$/))) viewPodcastDetail(decodeURIComponent(m[1]));
  else if (r === '/videos') viewVideos();
  else if (r === '/import') viewImport();
  else if (r === '/classroom') viewClassroom();
  else notFound();
  paintIcons(); syncPlayer();
}
window.addEventListener('hashchange', () => { render(); window.scrollTo(0, 0); });
onChange(() => { renderAuth(); render(); paintIcons(); });

renderAuth(); render(); paintIcons();
GC.loadClientId().then(() => { if (route() === '/classroom') render(); });
initAuth().then(() => GC.loadClientId()).then(() => { if (route() === '/classroom') render(); });
