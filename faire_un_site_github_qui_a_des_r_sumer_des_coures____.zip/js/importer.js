// Extraction de texte (PDF, Word, texte, image) + résumé IA
const PDFJS = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.min.mjs';
const PDFJS_WORKER = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.worker.min.mjs';
const MAMMOTH = 'https://cdn.jsdelivr.net/npm/mammoth@1.8.0/mammoth.browser.min.js';

function loadScript(src) {
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.onload = res; s.onerror = () => rej(new Error('Chargement impossible : ' + src));
    document.head.appendChild(s);
  });
}

export async function extractText(file) {
  const name = (file.name || '').toLowerCase();
  const type = file.type || '';
  if (type === 'application/pdf' || name.endsWith('.pdf')) {
    const pdfjs = await import(PDFJS);
    pdfjs.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
    const doc = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
    let out = '';
    const max = Math.min(doc.numPages, 60);
    for (let i = 1; i <= max; i++) {
      const page = await doc.getPage(i);
      const tc = await page.getTextContent();
      out += tc.items.map((it) => it.str).join(' ') + '\n\n';
    }
    return out.trim();
  }
  if (name.endsWith('.docx') || type.includes('wordprocessingml')) {
    if (!window.mammoth) await loadScript(MAMMOTH);
    const r = await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return r.value.trim();
  }
  if (type.startsWith('image/')) {
    if (!window.puter?.auth?.isSignedIn()) throw new Error('Connectez-vous pour lire le texte des images.');
    const t = await puter.ai.img2txt(file);
    return String(t || '').trim();
  }
  return (await file.text()).trim();
}

function contentOf(res) {
  if (typeof res === 'string') return res;
  const c = res?.message?.content;
  if (typeof c === 'string') return c;
  if (Array.isArray(c)) return c.map((p) => p.text || '').join('');
  return String(res ?? '');
}

export async function summarize({ text, title, subjectName, kind }) {
  const hasText = text && text.trim().length > 40;
  const body = hasText
    ? `Contenu du document :\n"""\n${text.slice(0, 24000)}\n"""`
    : `Aucun document fourni : rédige le résumé à partir de tes connaissances sur le sujet « ${title} », au niveau licence appliquée (ISET).`;
  const prompt = `Tu es un assistant pédagogique pour les étudiants de l'ISET Nabeul (Tunisie).
Rédige en français un résumé de ${kind === 'tp' ? 'travaux pratiques (TP)' : 'cours'} clair, fidèle et utile pour réviser.
Matière : ${subjectName}
Titre proposé : ${title || '(à déduire du contenu)'}

Réponds UNIQUEMENT avec un objet JSON valide, sans aucun texte autour ni balise markdown, de la forme :
{"title":"titre court","summary":"un paragraphe de 3 à 5 phrases","points":["5 à 8 points clés${kind === 'tp' ? ' (étapes et consignes du TP)' : ''}"],"formulas":["formules ou commandes importantes, tableau vide si aucune"],"terms":[["terme","définition courte"]],"duration":"durée de lecture, ex. 8 min"}

${body}`;
  const res = await puter.ai.chat(prompt);
  const raw = contentOf(res);
  const start = raw.indexOf('{'), end = raw.lastIndexOf('}');
  if (start < 0 || end < 0) throw new Error("La réponse de l'IA n'a pas pu être lue. Réessayez.");
  let data;
  try { data = JSON.parse(raw.slice(start, end + 1)); } catch (e) { throw new Error("La réponse de l'IA n'a pas pu être lue. Réessayez."); }
  return {
    title: String(data.title || title || 'Cours importé').slice(0, 140),
    summary: String(data.summary || ''),
    points: (Array.isArray(data.points) ? data.points : []).map(String).slice(0, 12),
    formulas: (Array.isArray(data.formulas) ? data.formulas : []).map(String).slice(0, 10),
    terms: (Array.isArray(data.terms) ? data.terms : [])
      .map((t) => Array.isArray(t) ? [String(t[0] ?? ''), String(t[1] ?? '')] : [String(t.term ?? t.terme ?? ''), String(t.definition ?? t.def ?? '')])
      .filter((t) => t[0]).slice(0, 10),
    duration: String(data.duration || '6 min'),
  };
}
