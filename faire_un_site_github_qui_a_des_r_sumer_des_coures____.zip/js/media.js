// Génération des scripts de podcast / vidéo et lecteur vocal
import { state } from './store.js';

const clean = (s) => String(s || '').replace(/[₀-₉]/g, (c) => String(c.charCodeAt(0) - 8320)).replace(/[*_#`]/g, '').trim();

export function podcastScript(item, subjectName, kind = 'cours') {
  const segs = [];
  segs.push({ label: 'Introduction', text: `Bonjour et bienvenue dans les podcasts de révision de l'ISET Nabeul. Aujourd'hui, en ${subjectName}, on parle de : ${item.title}.` });
  if (item.summary) segs.push({ label: 'Résumé', text: clean(item.summary) });
  if (item.objectives?.length) segs.push({ label: 'Objectifs', text: 'Les objectifs de ce TP sont : ' + item.objectives.map(clean).join('. ') + '.' });
  const pts = item.points || item.steps || [];
  pts.forEach((p, i) => segs.push({ label: (item.steps ? 'Étape ' : 'Point clé ') + (i + 1), text: (i === 0 ? (item.steps ? 'Première étape. ' : 'Premier point clé. ') : i === pts.length - 1 ? 'Enfin. ' : '') + clean(p) }));
  if (item.terms?.length) segs.push({ label: 'Vocabulaire', text: 'Petit rappel de vocabulaire. ' + item.terms.map(([t, d]) => `${clean(t)} : ${clean(d)}`).join('. ') + '.' });
  if (item.tip) segs.push({ label: 'Astuce', text: 'Une astuce pour finir : ' + clean(item.tip) });
  if (item.questions?.length) segs.push({ label: 'Questions', text: 'Pour vérifier votre compréhension, essayez de répondre à ces questions. ' + item.questions.map(clean).join(' ') });
  segs.push({ label: 'Conclusion', text: `C'est la fin de cet épisode sur ${item.title}. Bonne révision et à bientôt !` });
  return segs;
}

export function videoSlides(item, subjectName) {
  const slides = [];
  slides.push({ type: 'title', title: item.title, sub: subjectName, narration: `${item.title}. Un résumé en vidéo pour réviser ${subjectName}.` });
  if (item.summary) slides.push({ type: 'text', heading: "L'essentiel", body: item.summary, narration: clean(item.summary) });
  if (item.objectives?.length) slides.push({ type: 'list', heading: 'Objectifs', items: item.objectives, narration: 'Objectifs : ' + item.objectives.map(clean).join('. ') });
  const pts = item.points || item.steps || [];
  pts.forEach((p, i) => slides.push({ type: 'point', heading: item.steps ? `Étape ${i + 1}` : `Point clé ${i + 1}`, index: i + 1, total: pts.length, body: p, narration: clean(p) }));
  if (item.formulas?.length) slides.push({ type: 'formulas', heading: 'Formules et commandes', items: item.formulas, narration: 'Retenez les formules affichées à l’écran.' });
  if (item.terms?.length) slides.push({ type: 'terms', heading: 'Vocabulaire', items: item.terms.slice(0, 5), narration: item.terms.slice(0, 5).map(([t, d]) => `${clean(t)} : ${clean(d)}`).join('. ') });
  if (item.tip) slides.push({ type: 'text', heading: 'Astuce', body: item.tip, narration: clean(item.tip) });
  slides.push({ type: 'end', title: 'Bonne révision !', sub: 'ISET Nabeul', narration: 'Fin du résumé. Bonne révision !' });
  return slides;
}

// ---------- Lecteur vocal ----------
function splitSentences(text) {
  const parts = String(text).match(/[^.!?;:]+[.!?;:]*/g) || [text];
  const out = [];
  let buf = '';
  parts.forEach((p) => { if ((buf + p).length > 220 && buf) { out.push(buf.trim()); buf = p; } else buf += p; });
  if (buf.trim()) out.push(buf.trim());
  return out;
}

function frenchVoice() {
  const vs = window.speechSynthesis?.getVoices() || [];
  return vs.find((v) => /fr/i.test(v.lang) && /google|natural|online|neural/i.test(v.name))
      || vs.find((v) => /^fr/i.test(v.lang)) || null;
}

const aiCache = new Map();
async function aiAudio(text) {
  if (aiCache.has(text)) return aiCache.get(text);
  const p = puter.ai.txt2speech(text, {
    provider: 'openai', model: 'gpt-4o-mini-tts', voice: 'nova',
    instructions: 'Parle en français avec un ton chaleureux et pédagogique, comme une animatrice de podcast éducatif.',
  });
  aiCache.set(text, p);
  try { return await p; } catch (e) { aiCache.delete(text); throw e; }
}

export class Narrator {
  constructor(segments, { onSegment, onState, onEnd, onError } = {}) {
    this.segments = segments;
    this.i = 0;
    this.playing = false;
    this.rate = 1;
    this.token = 0;
    this.audio = null;
    this.cb = { onSegment, onState, onEnd, onError };
  }
  get mode() { return state.voiceMode === 'ai' && window.puter?.auth?.isSignedIn() ? 'ai' : 'browser'; }
  _state() { this.cb.onState?.(this.playing); }
  play(from = this.i) {
    this.stop(true);
    this.i = Math.max(0, Math.min(from, this.segments.length - 1));
    this.playing = true;
    this._state();
    this._run(++this.token);
  }
  pause() { this.stop(true); this.playing = false; this._state(); }
  toggle() { this.playing ? this.pause() : this.play(this.i); }
  next() { if (this.i < this.segments.length - 1) this.play(this.i + 1); }
  prev() { this.play(Math.max(0, this.i - 1)); }
  setRate(r) { this.rate = r; if (this.audio) this.audio.playbackRate = r; else if (this.playing) this.play(this.i); }
  stop(silent) {
    this.token++;
    try { window.speechSynthesis?.cancel(); } catch (e) {}
    if (this.audio) { this.audio.pause(); this.audio = null; }
    if (!silent) { this.playing = false; this._state(); }
  }
  async _run(tok) {
    while (tok === this.token && this.i < this.segments.length) {
      this.cb.onSegment?.(this.i);
      const text = this.segments[this.i].text || this.segments[this.i].narration || '';
      try {
        if (this.mode === 'ai') await this._speakAI(text, tok);
        else await this._speakBrowser(text, tok);
      } catch (e) {
        if (tok !== this.token) return;
        this.playing = false; this._state();
        this.cb.onError?.(e);
        return;
      }
      if (tok !== this.token) return;
      if (this.i >= this.segments.length - 1) break;
      this.i++;
    }
    if (tok === this.token) { this.playing = false; this._state(); this.cb.onEnd?.(); }
  }
  async _speakAI(text, tok) {
    const audio = await aiAudio(text);
    if (tok !== this.token) return;
    // prefetch next
    const nx = this.segments[this.i + 1];
    if (nx) aiAudio(nx.text || nx.narration || '').catch(() => {});
    this.audio = audio;
    audio.currentTime = 0;
    audio.playbackRate = this.rate;
    await new Promise((res, rej) => {
      audio.onended = res;
      audio.onerror = () => rej(new Error('Lecture audio impossible.'));
      audio.play().catch(rej);
    });
    this.audio = null;
  }
  async _speakBrowser(text, tok) {
    const synth = window.speechSynthesis;
    if (!synth) throw new Error("La synthèse vocale n'est pas disponible dans ce navigateur.");
    const voice = frenchVoice();
    for (const chunk of splitSentences(text)) {
      if (tok !== this.token) return;
      await new Promise((res) => {
        const u = new SpeechSynthesisUtterance(chunk);
        u.lang = 'fr-FR';
        if (voice) u.voice = voice;
        u.rate = this.rate;
        let done = false;
        const fin = () => { if (!done) { done = true; clearTimeout(guard); res(); } };
        u.onend = fin; u.onerror = fin;
        const guard = setTimeout(fin, Math.max(4000, chunk.length * 110 / this.rate));
        synth.speak(u);
      });
    }
  }
}
if (window.speechSynthesis) { window.speechSynthesis.getVoices(); window.speechSynthesis.onvoiceschanged = () => {}; }
